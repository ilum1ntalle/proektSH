public class Employee {
    String name, position;
    double salary;
    Employee(String name, String position, double salary) { this.name = name; this.position = position; this.salary = salary; }
    void showInfo() { System.out.println(name + ", должность: " + position + ", зарплата: " + salary + " тг."); }
    public static void demo() { new Employee("Данияр", "Разработчик", 350000).showInfo(); }
}
