public class Car {
    String brand, model;
    int year;

    Car(String brand, String model, int year) {
        this.brand = brand; this.model = model; this.year = year;
    }
    void showInfo() { System.out.println(brand + " " + model + ", год: " + year); }
    public static void demo() {
        Car a = new Car("Toyota", "Camry", 2022);
        Car b = new Car("BMW", "X5", 2024);
        a.showInfo(); b.showInfo();
    }
}
