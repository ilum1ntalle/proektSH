public class Flight {
    String flightNumber, destination; int availableSeats;
    Flight(String flightNumber, String destination, int availableSeats) { this.flightNumber = flightNumber; this.destination = destination; this.availableSeats = Math.max(0, availableSeats); }
    void bookSeat() {
        if (availableSeats > 0) { availableSeats--; System.out.println("Место забронировано."); }
        else System.out.println("Свободных мест нет.");
    }
    public static void demo() {
        Flight f = new Flight("KC123", "Алматы", 2);
        f.bookSeat(); System.out.println("Осталось мест: " + f.availableSeats);
    }
}
