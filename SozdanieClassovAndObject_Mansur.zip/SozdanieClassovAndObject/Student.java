public class Student {
    String name;
    int age;
    String group;

    Student(String name, int age, String group) {
        this.name = name; this.age = age; this.group = group;
    }

    void showInfo() {
        System.out.println("Имя: " + name + ", возраст: " + age + ", группа: " + group);
    }

    public static void demo() {
        Student s = new Student("Али", 18, "ПО-24");
        s.showInfo();
    }
}
