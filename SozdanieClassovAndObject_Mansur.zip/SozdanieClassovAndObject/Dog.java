public class Dog {
    String name, breed;
    Dog(String name, String breed) { this.name = name; this.breed = breed; }
    void bark() { System.out.println(name + " лает: Гав-гав!"); }
    public static void demo() { Dog d = new Dog("Рекс", "Овчарка"); System.out.println(d.name + ", порода: " + d.breed); d.bark(); }
}
