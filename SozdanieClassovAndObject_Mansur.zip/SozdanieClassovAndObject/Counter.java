public class Counter {
    int count;
    void increase() { count++; }
    void decrease() { if (count > 0) count--; }
    void reset() { count = 0; }
    public static void demo() {
        Counter c = new Counter(); c.increase(); c.increase(); c.decrease();
        System.out.println("Счётчик: " + c.count); c.reset(); System.out.println("После сброса: " + c.count);
    }
}
