public class UniversitySystem {
    public static void demo() {
        UniStudent s1 = new UniStudent("Али", "ПО-24");
        UniStudent s2 = new UniStudent("Дана", "ПО-24");
        Teacher t1 = new Teacher("Ирина Сергеевна", "Java");
        Teacher t2 = new Teacher("Марат Ерланович", "Базы данных");
        Course c1 = new Course("Основы Java", 72);
        Course c2 = new Course("SQL", 48);
        s1.showInfo(); s2.showInfo(); t1.showInfo(); t2.showInfo(); c1.showInfo(); c2.showInfo();
    }
}
