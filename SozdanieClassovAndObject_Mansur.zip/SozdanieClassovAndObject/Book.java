public class Book {
    String title, author;
    int pages;
    Book(String title, String author, int pages) {
        this.title = title; this.author = author; this.pages = pages;
    }
    void showInfo() { System.out.println("«" + title + "», автор: " + author + ", страниц: " + pages); }
    public static void demo() { new Book("Мастер и Маргарита", "Михаил Булгаков", 480).showInfo(); }
}
