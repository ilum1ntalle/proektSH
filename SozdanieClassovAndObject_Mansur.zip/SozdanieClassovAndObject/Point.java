public class Point {
    double x, y;
    Point(double x, double y) { this.x = x; this.y = y; }
    double distanceFromOrigin() { return Math.sqrt(x * x + y * y); }
    public static void demo() {
        Point p = new Point(3, 4);
        System.out.println("Расстояние до начала координат: " + p.distanceFromOrigin());
    }
}
