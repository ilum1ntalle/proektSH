public class Product {
    String name; double price; int quantity;
    Product(String name, double price, int quantity) { this.name = name; this.price = price; this.quantity = quantity; }
    double totalValue() { return price * quantity; }
    public static void demo() {
        Product p = new Product("Тетрадь", 250, 12);
        System.out.println(p.name + ": " + p.quantity + " шт., общая стоимость: " + p.totalValue() + " тг.");
    }
}
