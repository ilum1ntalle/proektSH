public class BankAccount {
    String owner; double balance;
    BankAccount(String owner, double balance) { this.owner = owner; this.balance = Math.max(0, balance); }
    void deposit(double amount) {
        if (amount > 0) { balance += amount; System.out.println("Пополнение: " + amount); }
        else System.out.println("Сумма пополнения должна быть больше нуля.");
    }
    void withdraw(double amount) {
        if (amount <= 0) System.out.println("Сумма снятия должна быть больше нуля.");
        else if (amount > balance) System.out.println("Недостаточно средств.");
        else balance -= amount;
    }
    void showBalance() { System.out.println(owner + ": баланс " + balance + " тг."); }
    public static void demo() {
        BankAccount a = new BankAccount("Али", 10000);
        a.deposit(2500); a.withdraw(1000); a.showBalance();
    }
}
