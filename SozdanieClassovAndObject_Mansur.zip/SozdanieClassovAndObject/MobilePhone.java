public class MobilePhone {
    String brand; int batteryLevel; boolean isOn;
    MobilePhone(String brand, int batteryLevel) {
        this.brand = brand; this.batteryLevel = Math.max(0, Math.min(100, batteryLevel)); this.isOn = false;
    }
    void turnOn() { if (batteryLevel > 0) { isOn = true; System.out.println("Телефон включён."); } else System.out.println("Заряд разряжен."); }
    void turnOff() { isOn = false; System.out.println("Телефон выключен."); }
    void useBattery(int amount) {
        if (amount < 0) { System.out.println("Расход не может быть отрицательным."); return; }
        batteryLevel = Math.max(0, batteryLevel - amount);
        if (batteryLevel == 0) isOn = false;
        System.out.println("Заряд: " + batteryLevel + "%");
    }
    public static void demo() { MobilePhone p = new MobilePhone("Samsung", 70); p.turnOn(); p.useBattery(25); p.turnOff(); }
}
