public class StudentExam {
    String name; int grade;
    StudentExam(String name, int grade) {
        this.name = name;
        if (grade < 0 || grade > 100) throw new IllegalArgumentException("Оценка должна быть от 0 до 100.");
        this.grade = grade;
    }
    boolean passed() { return grade >= 50; }
    public static void demo() {
        StudentExam a = new StudentExam("Алия", 78);
        StudentExam b = new StudentExam("Марат", 42);
        System.out.println(a.name + ": " + (a.passed() ? "сдал" : "не сдал"));
        System.out.println(b.name + ": " + (b.passed() ? "сдал" : "не сдал"));
    }
}
