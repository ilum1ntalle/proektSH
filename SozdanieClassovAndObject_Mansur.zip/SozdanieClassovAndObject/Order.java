public class Order {
    int orderNumber; String productName; double price; int quantity;
    Order(int orderNumber, String productName, double price, int quantity) { this.orderNumber = orderNumber; this.productName = productName; this.price = price; this.quantity = quantity; }
    double total() { return price * quantity; }
    void changeQuantity(int quantity) { if (quantity >= 0) this.quantity = quantity; else System.out.println("Количество не может быть отрицательным."); }
    public static void demo() {
        Order o = new Order(1001, "Клавиатура", 12000, 2);
        System.out.println("Заказ №" + o.orderNumber + ", сумма: " + o.total());
        o.changeQuantity(3); System.out.println("Новая сумма: " + o.total());
    }
}
