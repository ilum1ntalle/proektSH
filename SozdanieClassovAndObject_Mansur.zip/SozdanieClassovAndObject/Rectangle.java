public class Rectangle {
    double width, height;
    Rectangle(double width, double height) { this.width = width; this.height = height; }
    double area() { return width * height; }
    double perimeter() { return 2 * (width + height); }
    public static void demo() {
        Rectangle r = new Rectangle(5, 3);
        System.out.println("Площадь: " + r.area() + ", периметр: " + r.perimeter());
    }
}
