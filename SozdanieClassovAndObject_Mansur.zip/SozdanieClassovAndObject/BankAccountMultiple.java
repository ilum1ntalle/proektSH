public class BankAccountMultiple {
    public static void demo() {
        BankAccount first = new BankAccount("Али", 10000);
        BankAccount second = new BankAccount("Алия", 20000);
        first.deposit(5000); first.withdraw(2000); second.withdraw(3000);
        first.showBalance(); second.showBalance();
        System.out.println("Счета независимы: изменение первого не меняет второй.");
    }
}
