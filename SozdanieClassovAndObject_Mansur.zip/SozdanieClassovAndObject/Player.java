public class Player {
    String name; int health, damage;
    Player(String name, int health, int damage) { this.name = name; this.health = Math.max(0, health); this.damage = Math.max(0, damage); }
    void attack(Player target) { if (health > 0) { target.takeDamage(damage); System.out.println(name + " атакует " + target.name); } }
    void takeDamage(int amount) { health = Math.max(0, health - Math.max(0, amount)); }
    public static void demo() {
        Player a = new Player("Рыцарь", 100, 30); Player b = new Player("Орк", 80, 20);
        a.attack(b); b.attack(a);
        System.out.println(a.name + ": HP " + a.health); System.out.println(b.name + ": HP " + b.health);
    }
}
