public class LibraryBook {
    String title, author; boolean isAvailable;
    LibraryBook(String title, String author) { this.title = title; this.author = author; this.isAvailable = true; }
    void borrow() {
        if (isAvailable) { isAvailable = false; System.out.println("Книга выдана: " + title); }
        else System.out.println("Книга уже выдана.");
    }
    void returnBook() { isAvailable = true; System.out.println("Книга возвращена: " + title); }
    public static void demo() {
        LibraryBook b = new LibraryBook("Java для начинающих", "Автор");
        b.borrow(); b.borrow(); b.returnBook(); b.borrow();
    }
}
