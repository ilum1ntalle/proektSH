public class Circle {
    double radius;
    Circle(double radius) { this.radius = radius; }
    double area() { return Math.PI * radius * radius; }
    public static void demo() {
        Circle c = new Circle(4);
        System.out.printf("Площадь круга: %.2f%n", c.area());
    }
}
