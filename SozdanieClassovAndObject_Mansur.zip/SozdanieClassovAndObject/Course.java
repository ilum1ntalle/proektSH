public class Course {
    String title; int hours;
    Course(String title, int hours) { this.title = title; this.hours = hours; }
    void showInfo() { System.out.println("Курс: " + title + ", часов: " + hours); }
}
