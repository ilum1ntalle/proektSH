public class Computer {
    String brand, processor; int ram; double price;
    Computer(String brand, String processor, int ram, double price) { this.brand = brand; this.processor = processor; this.ram = ram; this.price = price; }
    void showInfo() { System.out.println(brand + " | " + processor + " | RAM " + ram + " ГБ | " + price + " тг."); }
    public static void demo() {
        new Computer("Lenovo", "Intel i5", 16, 300000).showInfo();
        new Computer("HP", "Intel i7", 32, 450000).showInfo();
        new Computer("ASUS", "Ryzen 5", 16, 340000).showInfo();
    }
}
