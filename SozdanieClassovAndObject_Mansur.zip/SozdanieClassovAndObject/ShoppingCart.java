public class ShoppingCart {
    String productName; double price; int quantity;
    ShoppingCart(String productName, double price, int quantity) { this.productName = productName; this.price = price; this.quantity = quantity; }
    double total() { return price * quantity; }
    void changeQuantity(int newQuantity) { if (newQuantity >= 0) quantity = newQuantity; else System.out.println("Количество не может быть отрицательным."); }
    public static void demo() {
        ShoppingCart c = new ShoppingCart("Мышь", 5000, 2);
        System.out.println("Сумма: " + c.total()); c.changeQuantity(3); System.out.println("После изменения: " + c.total());
    }
}
