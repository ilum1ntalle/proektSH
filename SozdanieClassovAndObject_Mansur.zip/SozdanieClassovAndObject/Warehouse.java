public class Warehouse {
    String productName; int quantity, capacity;
    Warehouse(String productName, int quantity, int capacity) {
        if (capacity < 0 || quantity < 0 || quantity > capacity) throw new IllegalArgumentException("Проверьте количество и вместимость.");
        this.productName = productName; this.quantity = quantity; this.capacity = capacity;
    }
    void add(int amount) {
        if (amount <= 0) System.out.println("Добавляемое количество должно быть больше нуля.");
        else if (quantity + amount > capacity) System.out.println("Нельзя добавить: превышена вместимость.");
        else quantity += amount;
    }
    void remove(int amount) {
        if (amount <= 0) System.out.println("Количество должно быть больше нуля.");
        else if (amount > quantity) System.out.println("На складе недостаточно товара.");
        else quantity -= amount;
    }
    public static void demo() {
        Warehouse w = new Warehouse("Коробки", 10, 15);
        w.add(3); w.remove(2);
        System.out.println(w.productName + ": " + w.quantity + "/" + w.capacity);
    }
}
