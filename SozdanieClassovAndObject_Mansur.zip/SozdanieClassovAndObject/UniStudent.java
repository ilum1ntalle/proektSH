public class UniStudent {
    String name, group;
    UniStudent(String name, String group) { this.name = name; this.group = group; }
    void showInfo() { System.out.println("Студент: " + name + ", группа: " + group); }
}
