public class Temperature {
    double celsius;
    Temperature(double celsius) { this.celsius = celsius; }
    double toFahrenheit() { return celsius * 9 / 5 + 32; }
    double toKelvin() { return celsius + 273.15; }
    public static void demo() {
        Temperature t = new Temperature(25);
        System.out.printf("%.1f C = %.1f F = %.2f K%n", t.celsius, t.toFahrenheit(), t.toKelvin());
    }
}
