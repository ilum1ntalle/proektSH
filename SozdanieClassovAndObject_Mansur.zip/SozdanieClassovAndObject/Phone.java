public class Phone {
    String brand, model;
    double price;
    Phone(String brand, String model, double price) { this.brand = brand; this.model = model; this.price = price; }
    void showInfo() { System.out.println(brand + " " + model + " — " + price + " тг."); }
    public static void demo() {
        new Phone("Apple", "iPhone 15", 350000).showInfo();
        new Phone("Samsung", "Galaxy S24", 320000).showInfo();
        new Phone("Xiaomi", "Redmi Note", 120000).showInfo();
    }
}
