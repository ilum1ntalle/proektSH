import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("\n========== ПРАКТИЧЕСКАЯ РАБОТА: ООП JAVA ==========");
            System.out.println("Введите номер задания от 1 до 30.");
            System.out.println("0 - выход");
            System.out.print("Ваш выбор: ");

            if (!sc.hasNextInt()) {
                System.out.println("Ошибка: введите целое число.");
                sc.nextLine();
                continue;
            }
            int choice = sc.nextInt();

            switch (choice) {
                case 0: System.out.println("Программа завершена."); sc.close(); return;
                case 1: Student.demo(); break;
                case 2: Car.demo(); break;
                case 3: Book.demo(); break;
                case 4: Phone.demo(); break;
                case 5: Cat.demo(); break;
                case 6: Dog.demo(); break;
                case 7: Rectangle.demo(); break;
                case 8: Circle.demo(); break;
                case 9: Employee.demo(); break;
                case 10: Laptop.demo(); break;
                case 11: BankAccount.demo(); break;
                case 12: Product.demo(); break;
                case 13: StudentExam.demo(); break;
                case 14: Counter.demo(); break;
                case 15: Movie.demo(); break;
                case 16: Temperature.demo(); break;
                case 17: Point.demo(); break;
                case 18: ShoppingCart.demo(); break;
                case 19: Clock.demo(); break;
                case 20: Flight.demo(); break;
                case 21: Computer.demo(); break;
                case 22: BankAccountMultiple.demo(); break;
                case 23: LibraryBook.demo(); break;
                case 24: StudentGroup.demo(); break;
                case 25: MobilePhone.demo(); break;
                case 26: CarMileage.demo(); break;
                case 27: Order.demo(); break;
                case 28: Player.demo(); break;
                case 29: Warehouse.demo(); break;
                case 30: UniversitySystem.demo(); break;
                default: System.out.println("Такого задания нет. Введите число от 1 до 30.");
            }
        }
    }
}
