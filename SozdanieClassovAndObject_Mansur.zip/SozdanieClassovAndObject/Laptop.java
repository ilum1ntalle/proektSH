public class Laptop {
    String brand; int ram; double price;
    Laptop(String brand, int ram, double price) { this.brand = brand; this.ram = ram; this.price = price; }
    void showInfo() { System.out.println(brand + ", RAM: " + ram + " ГБ, цена: " + price + " тг."); }
    public static void demo() {
        Laptop a = new Laptop("Lenovo", 16, 280000);
        Laptop b = new Laptop("ASUS", 32, 420000);
        a.showInfo(); b.showInfo();
        if (a.price > b.price) System.out.println(a.brand + " дороже.");
        else if (a.price < b.price) System.out.println(b.brand + " дороже.");
        else System.out.println("Ноутбуки стоят одинаково.");
    }
}
