public class Teacher {
    String name, subject;
    Teacher(String name, String subject) { this.name = name; this.subject = subject; }
    void showInfo() { System.out.println("Преподаватель: " + name + ", предмет: " + subject); }
}
