public class Clock {
    int hours, minutes, seconds;
    Clock(int hours, int minutes, int seconds) {
        if (hours < 0 || hours > 23 || minutes < 0 || minutes > 59 || seconds < 0 || seconds > 59)
            throw new IllegalArgumentException("Некорректное время.");
        this.hours = hours; this.minutes = minutes; this.seconds = seconds;
    }
    void showTime() { System.out.printf("%02d:%02d:%02d%n", hours, minutes, seconds); }
    public static void demo() { new Clock(9, 5, 7).showTime(); }
}
