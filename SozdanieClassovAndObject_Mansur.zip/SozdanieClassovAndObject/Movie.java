public class Movie {
    String title, genre; int duration;
    Movie(String title, String genre, int duration) { this.title = title; this.genre = genre; this.duration = duration; }
    void showInfo() { System.out.println(title + " | " + genre + " | " + duration + " мин."); }
    public static void demo() { new Movie("Интерстеллар", "Фантастика", 169).showInfo(); }
}
