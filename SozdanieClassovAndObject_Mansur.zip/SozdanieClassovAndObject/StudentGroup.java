public class StudentGroup {
    public static class GroupStudent {
        String name; double averageGrade;
        GroupStudent(String name, double averageGrade) { this.name = name; this.averageGrade = averageGrade; }
    }
    public static void demo() {
        GroupStudent[] students = {
            new GroupStudent("Али", 82.5), new GroupStudent("Алия", 91.2),
            new GroupStudent("Марат", 76.4), new GroupStudent("Дана", 88.0),
            new GroupStudent("Ильяс", 95.1)
        };
        GroupStudent best = students[0];
        for (GroupStudent s : students) if (s.averageGrade > best.averageGrade) best = s;
        System.out.println("Лучший студент: " + best.name + ", средний балл: " + best.averageGrade);
    }
}
