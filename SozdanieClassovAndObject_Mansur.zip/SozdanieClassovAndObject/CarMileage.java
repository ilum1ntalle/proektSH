public class CarMileage {
    String brand; double mileage, fuel;
    CarMileage(String brand, double mileage, double fuel) { this.brand = brand; this.mileage = mileage; this.fuel = fuel; }
    void drive(double km) {
        if (km <= 0) { System.out.println("Дистанция должна быть больше нуля."); return; }
        double needed = km / 10.0;
        if (needed > fuel) { System.out.println("Недостаточно топлива для поездки."); return; }
        mileage += km; fuel -= needed;
        System.out.println("Поездка завершена. Пробег: " + mileage + " км, топливо: " + fuel + " л.");
    }
    public static void demo() { CarMileage c = new CarMileage("Toyota", 12000, 20); c.drive(50); }
}
