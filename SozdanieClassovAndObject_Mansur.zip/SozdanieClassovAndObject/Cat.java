public class Cat {
    String name; int age;
    Cat(String name, int age) { this.name = name; this.age = age; }
    void meow() { System.out.println(name + " мяукает: Мяу!"); }
    public static void demo() { Cat c = new Cat("Мурка", 3); System.out.println(c.name + ", возраст: " + c.age); c.meow(); }
}
